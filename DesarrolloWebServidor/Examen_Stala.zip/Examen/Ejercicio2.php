<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <?php
        $numero = 12;
        $numeroFormato;
        $formato = 6;
        echo"El valor pasado es ";
        switch ($formato) {
            case 1:
                //decimal
                $numeroFormato = (int) $numero;
                $formato = " decimal";
                break;
            case 2:
                $numeroFormato = dechex($numero);
                $formato = " hexadecimal";
                break;
            case 3:
                //hexadecimal en mayuscula
                $numeroFormato = strtoupper(dechex($numero));
                $formato = " hexadecimal en mayúscula";
                break;
            case 4:
                //octal
                $numeroFormato = decoct($numero);
                $formato = " octal";
                break;
            case 5 :
                //exponencial
                //nose 
                break;
            case 6:
                //binario
                $numeroFormato = decbin($numero);
                $formato = " binario";
                break;
            default:
                echo "Formato incorrecto!!!!";
                break;
        }
        echo "$numeroFormato en $formato ";
    ?>
</body>
</html>
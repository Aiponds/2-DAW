<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    <?php
        $email = "vsta046@g.educaand.es";
        $separar = explode("@", $email);
        $nombre = $separar[0];
        $direccion = $separar[1];
        echo"El nombre es ". $nombre ." y la dirección es ". $direccion ."";
    ?>
</body>
</html>
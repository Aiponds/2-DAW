<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4</title>
</head>
<body>
    <?php
        $frase = "Hola que tal";
        $n = 2;
        $fraseSeparada = explode(" ",$frase);
        echo "La palabra numero $n es ".($fraseSeparada[$n-1]);
    ?> 
</body>
</html>
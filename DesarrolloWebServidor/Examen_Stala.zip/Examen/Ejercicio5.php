<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5</title>
</head>
<body>
    <?php
        $telefono = "950 48 10 00";
        if (preg_match_all('/[6789][0-9]{2}[ ][0-9]{2}[ ][0-9]{2}[ ][0-9]{2}/', $telefono)) {
            echo"Es válido el numero";
        } else {
            echo"No es válido el numero";
        }
    ?>
</body>
</html>
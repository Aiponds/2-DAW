<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <?php
        $cadena1 = "Hola10";
        $cadena2 = "Hola9";
        $modo = 4;
        $ncaracteres = 4;
        echo"Para el modo $modo :<br>";
        switch ($modo) {
            case 1:
                //comparacion de cadenas
                echo "Comparación de cadenas<br>";
                if(strcmp($cadena1, $cadena2) == 0) { 
                    echo $cadena1." es igual que ".$cadena2."";
                }else if(strcmp($cadena1, $cadena2) > 0) {
                    echo $cadena1." es mayor que ".$cadena2."";
                } else {
                    echo $cadena1." es menor que ".$cadena2."";
                }
                break;
            case 2:
                //comparacion de cadenas insensible a mayusculas y minusculas
                echo "Comparación de cadenas case insensitive<br>";
                if (strcasecmp($cadena1, $cadena2) == 0) {
                    echo $cadena1 . " es igual a " . $cadena2;
                } else if(strcasecmp($cadena1, $cadena2) > 0) {
                    echo $cadena1 . " es mayor que" . $cadena2;
                } else {
                    echo $cadena1." es menor que".$cadena2."";
                }
                break;
            case 3:
                //comparacion natural
                echo "Comparación de cadenas natural<br>";
                if (strnatcmp($cadena1, $cadena2) == 0) {
                    echo $cadena1 . " es igual a " . $cadena2;
                } else if(strnatcmp($cadena1, $cadena2) > 0) {
                    echo $cadena1 . " es mayor que" . $cadena2;
                } else {
                    echo $cadena1." es menor que".$cadena2."";
                }
                break;
            case 4:
                //comparacion de los n-primeros caracteres
                echo "Comparación de los $ncaracteres primeros caracteres<br>";
                if(strncmp($cadena1, $cadena2,$ncaracteres) == 0) { 
                    echo $cadena1." es igual que ".$cadena2."";
                }else if(strncmp($cadena1, $cadena2,$ncaracteres) > 0) {
                    echo $cadena1." es mayor que ".$cadena2."";
                } else {
                    echo $cadena1." es menor que ".$cadena2."";
                }
                break;
            default:
                echo "Modo no válido!";
                break;
        }
    ?>
</body>
</html>
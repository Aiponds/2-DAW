<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    <h1>Ejercicio 3</h1>
    <?php
        $cad = eliminaPalabra("Hola amigo, que tal", 3);
        print($cad);

        function eliminaPalabra($cadena, $posicion)
        {
            $array = preg_split("/[\s]+/", $cadena);
            //Comprueba que este dentro del rango del array la posicion introducida.
            if ($posicion >= 0 && $posicion < count($array)) {
                array_splice($array, $posicion-1, 1);
                $cadena_modificada = implode(' ', $array);
                return $cadena_modificada;
            } else {
                return $cadena;
            }
        }
    ?>

</body>
</html>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>

<body>
    <h1>Ejercicio 1</h1>
    <?php
    dibujarArbolNavidad(5);
    function dibujarArbolNavidad($altura)
    {
        // Generar el array del árbol
        $arbol = array();
        for ($i = 1; $i <= $altura; $i++) {
            $ramas = str_repeat("\\", $i * 2);
            $espacios = str_repeat("*", $altura - $i);
            $arbol[] = $espacios . str_pad($ramas, $altura + $i, "*", STR_PAD_BOTH);
        }
        echo '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; margin: auto;">';

        foreach ($arbol as $fila) {
            echo '<tr>';
            for ($j = 0; $j < strlen($fila); $j++) {
                $caracter = $fila[$j];
                $colorFondo = ($caracter === "\\") ? '#008000' : '#00FFFF';
                $colorTexto = ($caracter === "*") ? '#FFFFFF' : '#000000';
                echo '<td style="background-color: ' . $colorFondo . '; color: ' . $colorTexto . ';">' . $caracter . '</td>';
            }
            echo '</tr>';
        }

        echo '</table>';
    }
    ?>
</body>

</html>
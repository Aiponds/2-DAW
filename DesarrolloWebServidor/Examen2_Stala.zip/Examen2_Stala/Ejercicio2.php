<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <h1>Ejercicio 2</h1>
    <?php
        $array = array("Victor","Paco","Joaquín","Manolo");
        $criterio = 1;
        $array = ordenar($array, $criterio);
        echo "<pre>";
        print_r($array);
        echo "</pre>";
        function ordenar($array, $criterio=1){
            switch ($criterio) {
                case 1:
                    //de menor a mayor
                    rsort($array);
                    break;
                case 2:
                    //de mayor a menor
                    sort($array);
                    break;
                case 3:
                    //de menor a mayor por clave
                    krsort($array);
                    break;
                case 4:
                    //de mayor a menor por clave
                    ksort($array);
                    break;
                
                default:
                    print("Parámetro incorrecto");
                    break;
            }
            return $array;
        }
    ?>
</body>
</html>